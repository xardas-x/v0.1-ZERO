export const exampleGoals = [
  "I want to build overall strength for rock climbing",
  "I need a quick 30-minute workout to do at home",
  "Help me create a workout to improve my marathon training",
  "I want to focus on upper body strength with minimal equipment",
  "Create a full-body workout I can do 3 times per week",
  "I need a leg day workout with standard gym equipment",
  "Design a workout that will help improve my posture",
  "I want to train for explosive power for basketball",
  "Help me design a workout to lose weight and build muscle"
];